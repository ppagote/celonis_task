export const environment = {
  production: true,

  header_key: 'Celonis-Auth',
  header_value: 'totally_secret',

  base_url: 'http://localhost:8080/api/tasks/',
  execute_api: '/progress',
  cancel_api: '/cancel',
};
