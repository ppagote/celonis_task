import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CountTaskRoutingModule } from './count-task-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    CountTaskRoutingModule
  ]
})
export class CountTaskModule { }
