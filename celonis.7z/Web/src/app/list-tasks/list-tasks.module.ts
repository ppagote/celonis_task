import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ListTasksRoutingModule } from './list-tasks-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    ListTasksRoutingModule
  ]
})
export class ListTasksModule { }
