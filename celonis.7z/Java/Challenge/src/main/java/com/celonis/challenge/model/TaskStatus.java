package com.celonis.challenge.model;

public enum TaskStatus {
    Created("Created");

    TaskStatus(String created) {
    }
}
